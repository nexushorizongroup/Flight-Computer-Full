#pragma once
#include <Arduino.h>

void initIMUFilters();
void filterIMU(float& ax, float& ay, float& az,
               float& gx, float& gy, float& gz);

extern float vib_rms;
