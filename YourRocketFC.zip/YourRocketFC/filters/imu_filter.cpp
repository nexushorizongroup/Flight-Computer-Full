#include "imu_filter.h"
#include "esp_dsp.h"

static const int FIR_LEN = 21;
static float fir_coeffs[FIR_LEN];
static float ax_hist[FIR_LEN], ay_hist[FIR_LEN], az_hist[FIR_LEN];
static float gx_hist[FIR_LEN], gy_hist[FIR_LEN], gz_hist[FIR_LEN];

float vib_rms = 0.0f;

void initIMUFilters() {
    dsps_fir_gen_lpf_f32(fir_coeffs, FIR_LEN, 0.2f);
}

void filterIMU(float& ax, float& ay, float& az,
               float& gx, float& gy, float& gz) {
    // FIR filtering
    ax = dsps_fir_f32(ax_hist, fir_coeffs, FIR_LEN, ax);
    ay = dsps_fir_f32(ay_hist, fir_coeffs, FIR_LEN, ay);
    az = dsps_fir_f32(az_hist, fir_coeffs, FIR_LEN, az);

    gx = dsps_fir_f32(gx_hist, fir_coeffs, FIR_LEN, gx);
    gy = dsps_fir_f32(gy_hist, fir_coeffs, FIR_LEN, gy);
    gz = dsps_fir_f32(gz_hist, fir_coeffs, FIR_LEN, gz);

    // RMS vibration estimate
    float acc_mag = sqrtf(ax * ax + ay * ay + az * az);
    vib_rms = 0.95f * vib_rms + 0.05f * acc_mag;
}
