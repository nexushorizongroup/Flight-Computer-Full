#include "mag_fusion.h"
#include "../sensors/imu.h"
#include "../sensors/mag.h"
#include "ekf_adaptive.h"
#include <math.h>

float mag_yaw = 0;
bool mag_valid = false;

static float wrapAngle(float angle) {
    while (angle > M_PI) angle -= 2.0f * M_PI;
    while (angle < -M_PI) angle += 2.0f * M_PI;
    return angle;
}

void updateMagYaw() {
    float roll = imu_roll;
    float pitch = imu_pitch;
    float mx_ = ::mx;
    float my_ = ::my;
    float mz_ = ::mz;
    float mx2 = mx_ * cosf(pitch) + mz_ * sinf(pitch);
    float my2 = mx_ * sinf(roll) * sinf(pitch) + my_ * cosf(roll) - mz_ * sinf(roll) * cosf(pitch);
    mag_yaw = atan2f(-my2, mx2);
    float dyaw = wrapAngle(mag_yaw - imu_yaw);
    mag_valid = fabs(dyaw) <= 0.5f;
}
