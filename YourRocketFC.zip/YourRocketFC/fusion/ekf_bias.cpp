#include "ekf_bias.h"
#include "kalman.h"
#include <math.h>

static const float bias_tau = 60.0f; // seconds
static const float Q_bias = 1e-4f;

void ekfBiasPredict(float dt) {
    // Bias decay
    float decay = expf(-dt / bias_tau);
    ekf_bias *= decay;
    // Add process noise
    P[2][2] += Q_bias * dt;
}
