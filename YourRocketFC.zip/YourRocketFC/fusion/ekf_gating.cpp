#include "ekf_gating.h"
#include "kalman.h"
#include "gps_fusion.h"

bool gps_alt_gate_fail = false;
bool gps_vel_gate_fail = false;

void ekfInnovationGating() {
    float dz = gps_alt_fused - ekf_alt;
    float gate_alt = 5.0f * ubx_vAcc;
    gps_alt_gate_fail = fabs(dz) > gate_alt;

    float dv = gps_vel_fused - ekf_vel;
    float gate_vel = 5.0f * (fabs(ubx_veld) * 0.1f + ubx_vAcc * 0.2f);
    gps_vel_gate_fail = fabs(dv) > gate_vel;

    if (gps_alt_gate_fail || gps_vel_gate_fail) {
        gps_fused_valid = false;
    }
}
