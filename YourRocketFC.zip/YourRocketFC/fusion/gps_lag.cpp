#include "gps_lag.h"
#include "../fusion/time_fusion.h"
#include "../gps/ubx_parser.h"

float gps_alt_lagged = 0;
float gps_vel_lagged = 0;

void applyGPSLagCompensation() {
    uint64_t dt_us = globalTimeUs - ((uint64_t)ubx_tow_ms * 1000ULL);
    float dt = dt_us * 1e-6f;
    gps_alt_lagged = ubx_alt - ubx_veld * dt;
    gps_vel_lagged = ubx_veld;
}
