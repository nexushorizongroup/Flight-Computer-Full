pragma once

void ekfAdaptiveNoiseUpdate();
