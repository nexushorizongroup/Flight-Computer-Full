#pragma once
#include <Arduino.h>
void ekfConditionCovariance();
