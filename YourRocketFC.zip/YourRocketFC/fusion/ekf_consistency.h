#pragma once
#include <Arduino.h>
void ekfConsistencyCheck();
extern bool ekf_inconsistent;
