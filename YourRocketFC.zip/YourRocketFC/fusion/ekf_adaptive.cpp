include "ekf_adaptive.h"

include "kalman.h"

include "../core/globals.h"

include "../sensors/imu.h"

include "../sensors/baro.h"

include "../fusion/gps_fusion.h"

// Base noise values
static const float QALTBASE = 0.01f;
static const float QVELBASE = 0.10f;
static const float QBIASBASE = 0.001f;

static const float RBAROBASE = 4.0f;
static const float RGPSVEL_BASE = 4.0f;

// Mach lock noise multiplier
static const float MACHNOISEMULT = 5.0f;

void ekfAdaptiveNoiseUpdate() {

    float vib = vibration_level;  // 0.0–1.0
    float temp = imu_temp;        // °C
    float gpsq = gps_quality;     // 0.0–1.0 (from your fusion layer)

    // -----------------------------
    // IMU Temperature Scaling
    // -----------------------------
    float temp_scale = 1.0f + 0.02f * fabs(temp - 25.0f);

    // -----------------------------
    // Vibration Scaling
    // -----------------------------
    float vib_scale = 1.0f + 3.0f * vib;

    // -----------------------------
    // GPS Quality Scaling
    // -----------------------------
    float gps_scale = 1.0f + (1.0f - gpsq) * 4.0f;

    // -----------------------------
    // Mach Lock Scaling
    // -----------------------------
    float machscale = machLock ? MACHNOISE_MULT : 1.0f;

    // -----------------------------
    // Apply to Q (process noise)
    // -----------------------------
    Q[0][0] = QALTBASE   vibscale  tempscale;
    Q[1][1] = QVELBASE   vibscale  tempscale;
    Q[2][2] = QBIASBASE * temp_scale;

    // -----------------------------
    // Apply to R (measurement noise)
    // -----------------------------
    Rbaro = RBAROBASE  vibscale  mach_scale;

    Rgpsvel = RGPSVELBASE  gpsscale  vib_scale;
}
