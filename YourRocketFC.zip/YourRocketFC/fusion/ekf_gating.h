#pragma once
#include <Arduino.h>
void ekfInnovationGating();
extern bool gps_alt_gate_fail;
extern bool gps_vel_gate_fail;
