#pragma once
#include <Arduino.h>
void updateMagYaw();
extern float mag_yaw;
extern bool mag_valid;
