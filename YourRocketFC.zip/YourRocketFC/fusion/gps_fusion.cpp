#include "gps_fusion.h"
#include "../core/config.h"
#include "../core/globals.h"
#include "../sensors/gps.h"
#include "../fusion/time_fusion.h"

#include <CircularBuffer.h>

#define GPS_LAG_SEC 0.65f
#define GPS_ALPHA 0.6f
#define GPS_INNOVATION_THRESH 15.0f

float gps_quality = 1.0f; // 0.0–1.0

CircularBuffer<float, 15> altBuf;
CircularBuffer<uint64_t, 15> timeBuf;

float gps_alt_fused = 0;
float gps_vel_fused = 0;
bool gps_fused_valid = false;

gps_quality = constrain(
    1.0f - (hdop / 5.0f) - (1.0f - (satellites / 10.0f)),
    0.0f, 1.0f
);


void initGPSFusion() {
    altBuf.clear();
    timeBuf.clear();
    gps_alt_fused = 0;
    gps_vel_fused = 0;
    gps_fused_valid = false;
}

static float computeVelocity() {
    if (altBuf.size() < 4) return 0;

    float alt_now = altBuf.last();
    float alt_prev = altBuf[altBuf.size() - 4];

    uint64_t t_now = timeBuf.last();
    uint64_t t_prev = timeBuf[timeBuf.size() - 4];

    float dt = (t_now - t_prev) / 1e6f;
    if (dt <= 0.01f) return 0;

    return (alt_now - alt_prev) / dt;
}

void updateGPSFusion() {
    if (!ubx_valid) {
        gps_fused_valid = false;
        return;
    }

    // Push into circular buffers
    altBuf.push(ubx_alt);
    timeBuf.push(globalTimeUs);

    // Use direct UBX vertical velocity if available
    float vel_est = ubx_veld;

    // Lag compensation
    float alt_lag_fixed = ubx_alt + ubx_veld * GPS_LAG_SEC;

    // Innovation gating
    float innovation = fabs(alt_lag_fixed - ekf_alt);
    if (innovation > GPS_INNOVATION_THRESH) {
        gps_fused_valid = false;
        return;
    }

    // Alpha-blend smoothing
    gps_alt_fused = GPS_ALPHA * alt_lag_fixed + (1.0f - GPS_ALPHA) * gps_alt_fused;
    gps_vel_fused = vel_est;

    // GPS accuracy and fix
    float gpsaltaccuracy = ubx_vAcc;
    float gpsvelaccuracy = fabs(ubx_veld) * 0.1f + ubx_vAcc * 0.2f;
    gps_quality = constrain(1.0f - (gpsaltaccuracy / 20.0f), 0.0f, 1.0f);

    // Adaptive noise scaling for EKF (example usage)
    float R_gps_alt = fmaxf(6.0f, gpsaltaccuracy * (1.0f + (1.0f - gps_quality) * 5.0f));
    float R_gps_vel = fmaxf(4.0f, gpsvelaccuracy * (1.0f + (1.0f - gps_quality) * 5.0f));

    // Dropout detection
    static uint64_t last_gps_msg_us = 0;
    if (ubx_valid) last_gps_msg_us = globalTimeUs;
    bool gps_timeout = (globalTimeUs - last_gps_msg_us) > 300000ULL; // 0.3s
    bool gps_accuracy_bad = (gpsaltaccuracy > 20.0f || gpsvelaccuracy > 10.0f);
    bool gps_fix_bad = (ubx_fixType < 3);

    gps_fused_valid = (!gps_timeout && !gps_accuracy_bad && !gps_fix_bad && gps_quality > 0.2f);
}


