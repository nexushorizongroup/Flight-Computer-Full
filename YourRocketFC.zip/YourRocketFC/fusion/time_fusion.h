#pragma once
#include <Arduino.h>

void initTimeFusion();
void updateTimeFusion();

extern uint64_t globalTimeUs;
extern uint64_t launchTimeUs;
