#include "ahrs.h"
#include "../core/globals.h"
#include "../core/config.h"

#include <MadgwickAHRS.h>

Madgwick filter;

void initAHRS() {
    filter.begin(RATE_IMU_HZ);
}

void updateAHRS() {
    filter.updateIMU(
        imu_gx, imu_gy, imu_gz,
        imu_ax, imu_ay, imu_az
        imu_mx, imu_my, imu_mz
    );

    imu_roll = filter.getRoll();
    imu_pitch = filter.getPitch();
    imu_yaw = filter.getYaw();
}
