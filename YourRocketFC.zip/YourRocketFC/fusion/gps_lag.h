#pragma once
#include <Arduino.h>
void applyGPSLagCompensation();
extern float gps_alt_lagged;
extern float gps_vel_lagged;
