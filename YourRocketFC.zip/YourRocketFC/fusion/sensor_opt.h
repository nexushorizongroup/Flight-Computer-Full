#pragma once
#include <Arduino.h>

void optimizeIMU(float dt);
void optimizeBaro(float dt);
void optimizeGPS(float dt);
