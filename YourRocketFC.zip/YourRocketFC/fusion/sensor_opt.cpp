#include "sensor_opt.h"
#include "../core/globals.h"
#include "../core/config.h"

void optimizeIMU(float dt) {
    // Increase noise during vibration
    if (vibration_event) {
        P[1][1] += 0.5f;
    }
}

void optimizeBaro(float dt) {
    static float lastAlt = 0;
    float diff = baro_alt - lastAlt;

    if (fabs(diff) > 3.0f) {
        P[0][0] += 5.0f;
    }

    lastAlt = baro_alt;
}

void optimizeGPS(float dt) {
    static float lastGPS = 0;
    float diff = gps_alt_fused - lastGPS;

    if (fabs(diff) > 10.0f) {
        P[0][0] += 10.0f;
    }

    lastGPS = gps_alt_fused;
}
