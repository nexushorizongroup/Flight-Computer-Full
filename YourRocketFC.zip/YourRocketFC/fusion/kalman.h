#pragma once
#include <Arduino.h>

void initEKF();
void updateEKF();

// EKF state
extern float ekf_alt;
extern float ekf_vel;
extern float ekf_bias;

// Covariance matrix
extern float P[3][3];
