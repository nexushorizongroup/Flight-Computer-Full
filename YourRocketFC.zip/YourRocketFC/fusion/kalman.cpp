#include "kalman.h"
#include "../core/config.h"
#include "../core/globals.h"

float ekf_alt = 0;
float ekf_vel = 0;
float ekf_bias = 0;

float P[3][3] = {0};

static const float Q_alt = 0.01f;
static const float Q_vel = 0.1f;
static const float Q_bias = 0.00001f;

extern float baro_temp;
extern float imu_temp;

static const float R_baro = 4.0f;

// Innovation gate (m/s)
static const float R_gps = 25.0f;

// GPS velocity measurement noise (m/s)
static const float R_gps_vel = 5.0f; // Adjust based on sensor noise

void initEKF() {
    P[0][0] = 10;
    P[1][1] = 10;
    P[2][2] = 1;
}

void updateEKF() {
    float dt = 1.0f / RATE_FUSION_HZ;

    // -----------------------------
    // Prediction Step
    // -----------------------------
    float accel = imu_az - ekf_bias;

    ekf_alt += ekf_vel * dt + 0.5f * accel * dt * dt;
    ekf_vel += accel * dt;

    P[0][0] += Q_alt;
    P[1][1] += Q_vel;
    P[2][2] += Q_bias;

    // Temperature aware IMU noise
    float imunoisescale = 1.0f + 0.02f * fabs(imu_temp - 25.0f);

    // Increase Q during high temp drift
    P[0][0] = 0.01f * imunoisescale;
    P[1][1] = 0.1f  * imunoisescale;
    P[2][2] = 0.001f * imunoisescale;


    // -----------------------------
    // Barometer Update
    // -----------------------------
    // Temperature aware baro noise
    float baronoisescale = 1.0f + 0.03f * fabs(baro_temp - 25.0f);

    Rbaro = 4.0f * baronoise_scale;

    float z = baro_alt;
    float y = z - ekf_alt; // innovation
    float S = P[0][0] + R_baro;
    float K0 = P[0][0] / S;
    float K1 = P[1][0] / S;
    float K2 = P[2][0] / S;

    ekf_alt += K0 * y;
    ekf_vel += K1 * y;
    ekf_bias += K2 * y;

    P[0][0] *= (1 - K0);
    P[1][0] *= (1 - K0);
    P[2][0] *= (1 - K0);




    // -----------------------------
    // GPS Update (if valid)
    // -----------------------------
    if (gps_fused_valid) {
	// --- GPS Altitude Update ---
    	float zg = gps_alt_fused;
        float yg = zg - ekf_alt;
        float Sg = P[0][0] + R_gps;

        float Kg0 = P[0][0] / Sg;
        float Kg1 = P[1][0] / Sg;
        float Kg2 = P[2][0] / Sg;

        ekf_alt += Kg0 * yg;
        ekf_vel += Kg1 * yg;
        ekf_bias += Kg2 * yg;

        P[0][0] *= (1 - Kg0);
        P[1][0] *= (1 - Kg0);
        P[2][0] *= (1 - Kg0);

        // --- GPS Velocity Update (Robust Version) ---
        float zv = gps_vel_fused;
        float yv = zv - ekf_vel; // Innovation

        // 1. Innovation Gating: Reject outliers/glitches
        if (fabs(yv) < 25.0f) { 
    
            // 2. Adaptive Noise: Scale by vibration
            float R_gps_vel = 5.0f + (20.0f * vibration_level);
    
            // 3. Innovation Covariance (S)
            float Sv = P[1][1] + R_gps_vel; 

            // 4. Kalman Gains (K)
            float Kv0 = P[0][1] / Sv; // Gain for Alt
            float Kv1 = P[1][1] / Sv; // Gain for Vel
            float Kv2 = P[2][1] / Sv; // Gain for Bias

            // 5. Update State
            ekf_alt  += Kv0 * yv;
            ekf_vel  += Kv1 * yv;
            ekf_bias += Kv2 * yv;

            // 6. FULL Covariance Update: P = (I - KH)P
            // This is the "Good Math" you were missing.
            // We update all correlations based on the velocity gain (Kv).
            for (int i = 0; i < 3; i++) {
                float p_i1 = P[i][1]; // Cache the velocity column value
                P[i][0] -= Kv0 * p_i1;
                P[i][1] -= Kv1 * p_i1;
                P[i][2] -= Kv2 * p_i1;
            }
        }
    }
}
