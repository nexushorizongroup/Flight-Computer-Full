#pragma once
#include <Arduino.h>

void initAHRS();
void updateAHRS();

// Orientation outputs
extern float imu_pitch;
extern float imu_roll;
extern float imu_yaw;
