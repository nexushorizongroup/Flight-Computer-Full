#include "ekf_conditioning.h"
#include "kalman.h"
#include <math.h>

static const float P_MIN = 1e-6f;
static const float P_MAX = 1e6f;

void ekfConditionCovariance() {
    // Force symmetry
    P[0][1] = P[1][0];
    P[0][2] = P[2][0];
    P[1][2] = P[2][1];
    // Clamp diagonal elements
    for (int i = 0; i < 3; i++) {
        if (P[i][i] < P_MIN) P[i][i] = P_MIN;
        if (P[i][i] > P_MAX) P[i][i] = P_MAX;
    }
    // Clamp off-diagonals
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (fabs(P[i][j]) > P_MAX) {
                P[i][j] = copysign(P_MAX, P[i][j]);
            }
        }
    }
}
