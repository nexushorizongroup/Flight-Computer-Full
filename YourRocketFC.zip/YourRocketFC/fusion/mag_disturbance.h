#pragma once
#include <Arduino.h>
void detectMagDisturbance();
extern bool mag_disturbed;
