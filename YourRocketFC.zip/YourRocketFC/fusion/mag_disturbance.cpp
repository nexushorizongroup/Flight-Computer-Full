#include "mag_disturbance.h"
#include "../sensors/mag.h"
#include "mag_fusion.h"
#include <math.h>

bool mag_disturbed = false;

void detectMagDisturbance() {
    float mag_norm = sqrtf(mx * mx + my * my + mz * mz);
    bool magnitude_bad = (mag_norm < 20.0f || mag_norm > 70.0f);
    bool yaw_bad = fabs(mag_yaw - imu_yaw) > 0.5f;
    mag_disturbed = magnitude_bad || yaw_bad;
    if (mag_disturbed) mag_valid = false;
}
