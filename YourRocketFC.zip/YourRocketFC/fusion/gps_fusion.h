#pragma once
#include <Arduino.h>

void initGPSFusion();
void updateGPSFusion();

// Fused GPS outputs
extern float gps_alt_fused;
extern float gps_vel_fused;
extern bool gps_fused_valid;
