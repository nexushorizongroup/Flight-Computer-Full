#include "ekf_consistency.h"
#include "kalman.h"
#include "gps_fusion.h"
#include "ekf_gating.h"
#include <math.h>

bool ekf_inconsistent = false;

void ekfConsistencyCheck() {
    ekf_inconsistent = false;
    if (P[0][0] > 1e6f || P[1][1] > 1e6f || P[2][2] > 1e6f) ekf_inconsistent = true;
    if (P[0][0] < 1e-8f || P[1][1] < 1e-8f || P[2][2] < 1e-8f) ekf_inconsistent = true;
    if (gps_alt_gate_fail || gps_vel_gate_fail) ekf_inconsistent = true;
    if (gps_fused_valid && gps_quality < 0.2f) ekf_inconsistent = true;
    if (vibration_level > 0.9f) ekf_inconsistent = true;
    if (isnan(ekf_alt) || isnan(ekf_vel)) ekf_inconsistent = true;
}
