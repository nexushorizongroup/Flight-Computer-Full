#include "ekf_reset.h"
#include "kalman.h"
#include "gps_fusion.h"
#include "ekf_gating.h"
#include "ekf_consistency.h"
#include <math.h>

void ekfStateReset() {
    // 1. Altitude reset
    if (gps_alt_gate_fail) {
        ekf_alt = gps_alt_fused;
        P[0][0] = 10.0f;
    }
    // 2. Velocity reset
    if (gps_vel_gate_fail) {
        ekf_vel = gps_vel_fused;
        P[1][1] = 5.0f;
    }
    // 3. Bias reset if inconsistent
    if (ekf_inconsistent) {
        ekf_bias = 0.0f;
        P[2][2] = 0.1f;
    }
    // 4. Clamp covariance
    for (int i = 0; i < 3; i++) {
        if (P[i][i] < 1e-4f) P[i][i] = 1e-4f;
        if (P[i][i] > 1e4f) P[i][i] = 1e4f;
    }
}
