#include "time_fusion.h"
#include "../core/globals.h"
#include "../core/config.h"
#include "../sensors/rtc.h"
#include "../sensors/gps.h"

#include "../gps/ubx_parser.h"
#include "../gps/pps.h"

uint64_t globalTimeUs = 0;
uint64_t launchTimeUs = 0;
static uint64_t last_pps_us = 0;
static uint32_t last_tow_ms = 0;

void updateGlobalTime() {
    if (pps_flag && ubx_pps_valid) {
        pps_flag = false;
        last_pps_us = pps_last_us;
        last_tow_ms = ubx_tow_ms;
        globalTimeUs = (uint64_t)last_tow_ms * 1000ULL;
    }
    uint64_t dt_us = micros() - last_pps_us;
    globalTimeUs = (uint64_t)last_tow_ms * 1000ULL + dt_us;
}


void initTimeFusion() {
    globalTimeUs = getRTCTimeUs();
}

void updateTimeFusion() {
    globalTimeUs = getRTCTimeUs();
}
