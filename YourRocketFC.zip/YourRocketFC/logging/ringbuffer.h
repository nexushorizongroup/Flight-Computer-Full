#pragma once
#include <Arduino.h>

#define RINGBUFFER_SIZE 2048

struct LogEntry {
    uint32_t tflight_ms;
    float alt;
    float vel;
    float ax, ay, az;
    float gx, gy, gz;
    float pitch, roll, yaw;
    float baro_alt;
    float gps_alt;
    float light;
    float vibration;
    float temp;
    float battv;
    int flightState;
    bool pyro1_cont;
    bool pyro2_cont;
    bool pyro_inhibit;
    float gps_vel;
    bool wd_tripped;
    bool imu_stall;
    bool sd_stall;
    float baro_temp;
    float imu_temp;
    float mx, my, mz;
    bool mag_ok;

    float vib_level;
    float gps_quality;
    float Rbaro_log;
    float Rgpsvel_log;
    float Qalt_log;
    float Qvel_log;


    float lux_filt;
    float lux_deriv;
    bool cloud_detected;
    bool light_anomaly;


};

void initRingBuffer();
void pushLogEntry(const LogEntry &entry);
bool popLogEntry(LogEntry &entry);
bool ringBufferEmpty();
