#include "ringbuffer.h"

static LogEntry buffer[RINGBUFFER_SIZE];
static volatile int head = 0;
static volatile int tail = 0;

void initRingBuffer() {
    head = 0;
    tail = 0;
}

bool ringBufferEmpty() {
    return head == tail;
}

void pushLogEntry(const LogEntry &entry) {
    int next = (head + 1) % RINGBUFFER_SIZE;

    if (next == tail) {
        // Buffer full — overwrite oldest
        tail = (tail + 1) % RINGBUFFER_SIZE;
    }

    buffer[head] = entry;
    head = next;
}

bool popLogEntry(LogEntry &entry) {
    if (ringBufferEmpty()) return false;

    entry = buffer[tail];
    tail = (tail + 1) % RINGBUFFER_SIZE;
    return true;
}
