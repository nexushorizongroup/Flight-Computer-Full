#pragma once
#include <Arduino.h>

void initSD();
void logData();
