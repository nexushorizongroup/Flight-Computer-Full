#include "sdlog.h"
#include "ringbuffer.h"

#include "../core/globals.h"
#include "../core/config.h"

#include <SPI.h>
#include <SdFat.h>

SdFat sd;
SdFile logfile;

static uint64_t lastLogTime = 0;

void initSD() {
    if (!sd.begin(PIN_SD_SS, SD_SCK_MHZ(20))) {
        Serial.println("SD init failed!");
        return;
    }

    char filename[32];
    int index = 0;

    do {
        sprintf(filename, "LOG%03d.CSV", index++);
    } while (sd.exists(filename));

    logfile.open(filename, FILE_WRITE);

    logfile.println("time_us,alt,vel,ax,ay,az,gx,gy,gz,pitch,roll,yaw,baro_alt,gps_alt,light,vibration,temp,battv,pyro1_cont,pyro2_cont,pyro_inhibit,gps_vel,wdtripped,imustall,sdstall,state, baro_temp, imu_temp, mx, my, mz, mag_ok, vib_level, gps_quality, Rbaro_log, Rgpsvel_log,Qalt_log,Qvel_log, lux_filt, lux_deriv, cloud_detected, light_anomaly");
    logfile.flush();

    Serial.print("Logging to ");
    Serial.println(filename);
}

void logData() {
    uint64_t now = globalTimeUs;
    if (now - lastLogTime < (1000000ULL / LOG_RATE_HZ)) return;
    lastLogTime = now;

    LogEntry entry;
    entry.tflightms = (launchTimeUs == 0) ? 0 : (globalTimeUs - launchTimeUs) / 1000ULL;
    entry.alt = ekf_alt;
    entry.vel = ekf_vel;

    entry.ax = imu_ax;
    entry.ay = imu_ay;
    entry.az = imu_az;

    entry.gx = imu_gx;
    entry.gy = imu_gy;
    entry.gz = imu_gz;

    entry.pitch = imu_pitch;
    entry.roll = imu_roll;
    entry.yaw = imu_yaw;

    entry.baro_alt = baro_alt;
    entry.gps_alt = gps_alt_fused;

    entry.light = light_lux;
    entry.vibration = vibration_level;
    entry.temp = thermistor_temp;

    entry.battv = battery_voltage;

    entry.pyro1_cont = pyro1_cont;
    entry.pyro2_cont = pyro2_cont;
    entry.pyro_inhibit = pyro_inhibit;

    entry.gps_vel = gps_vel_fused;

    entry.wdtripped = watchdogtripped;
    entry.imustall = imustall_detected;
    entry.sdstall = sdstall_detected;


    entry.flightState = flightState;

    entry.baro_temp = baro_temp;
    entry.imu_temp = imu_temp;

    entry.mx = mx;
    entry.my = my;
    entry.mz = mz;
    entry.mag_ok = mag_ok;

    entry.vib_level = vibration_level;
    entry.gps_quality = gps_quality;
    entry.Rbaro_log = R_baro;
    entry.Rgpsvel_log = Rgps_vel;
    entry.Qalt_log = Q[0][0];
    entry.Qvel_log = Q[1][1];

    entry.luxfilt = lightlux_filtered;
    entry.luxderiv = lightlux_deriv;
    entry.clouddetected = clouddetected;
    entry.lightanomaly = lightanomaly;


    pushLogEntry(entry);

    // Write from buffer
    LogEntry out;
    while (popLogEntry(out)) {
        logfile.print(out.tflightms); logfile.print(",");
        logfile.print(out.alt); logfile.print(",");
        logfile.print(out.vel); logfile.print(",");
        logfile.print(out.ax); logfile.print(",");
        logfile.print(out.ay); logfile.print(",");
        logfile.print(out.az); logfile.print(",");
        logfile.print(out.gx); logfile.print(",");
        logfile.print(out.gy); logfile.print(",");
        logfile.print(out.gz); logfile.print(",");
        logfile.print(out.pitch); logfile.print(",");
        logfile.print(out.roll); logfile.print(",");
        logfile.print(out.yaw); logfile.print(",");
        logfile.print(out.baro_alt); logfile.print(",");
        logfile.print(out.gps_alt); logfile.print(",");
        logfile.print(out.light); logfile.print(",");
        logfile.print(out.vibration); logfile.print(",");
        logfile.print(out.temp); logfile.print(",");
        logfile.print(out.battv); logfile.print(",");
        logfile.print(out.pyro1_cont); logfile.print(",");
        logfile.print(out.pyro2_cont); logfile.print(",");
        logfile.print(out.pyro_inhibit); logfile.print(",");
        logfile.print(out.gps_vel); logfile.print(",");
        logfile.print(out.wdtripped); logfile.print(",");
        logfile.print(out.imustall); logfile.print(",");
        logfile.print(out.sdstall); logfile.print(",");
        logfile.println(out.flightState); logfile.print(",");
        logfile.println(out.baro_temp); logfile.print(",");
        logfile.println(out.imu_temp); logfile.print(",");
        logfile.println(out.mx); logfile.print(",");
        logfile.println(out.my); logfile.print(",");
        logfile.println(out.mz); logfile.print(",");
        logfile.println(out.mag_ok); logfile.print(",");

        logfile.println(out.vib_level); logfile.print(",");
        logfile.println(out.gps_quality); logfile.print(",");
        logfile.println(out.Rbaro_log); logfile.print(",");
        logfile.println(out.Rgpsvel_log); logfile.print(",");
        logfile.println(out.Qalt_log); logfile.print(",");
        logfile.println(out.Qvel_log);

        logfile.println(out.luxfilt); logfile.print(",");
        logfile.println(out.luxderiv); logfile.print(",");
        logfile.println(out.clouddetected); logfile.print(",");
        logfile.println(out.lightanomaly);

    }
    notifySDWrite();
    logfile.flush();
}
