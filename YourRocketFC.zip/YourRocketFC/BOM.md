# YourRocketFC Bill of Materials (BOM)

| Subsystem         | Part/IC/Module        | Example Part #         | Interface      | Notes                                  |
|-------------------|----------------------|------------------------|---------------|----------------------------------------|
| MCU               | ESP32-S3             | ESP32-S3-WROOM-1       | -             | Main processor, WiFi/BT, FreeRTOS      |
| IMU               | 9-axis IMU           | ICM-20948              | SPI           | Accel/Gyro/Mag                         |
| Barometer         | Barometric sensor    | MS5611                 | I2C           | High-res altimeter                     |
| GPS               | GNSS module          | u-blox NEO-M9N         | UART, PPS     | UBX, 10Hz+, airborne model             |
| Light Sensor      | Ambient light sensor | TSL2561                | I2C           | Sun/cloud detection                    |
| Vibration         | Vibration sensor     | SW-420 or Piezo        | Analog/Digital| Motor/flight vibration                 |
| Thermistor        | NTC Thermistor       | NTC 10k                | Analog        | Board/ambient temperature              |
| RTC               | Real-Time Clock      | DS3231M                | I2C           | Battery-backed, temp compensated       |
| Magnetometer      | (in ICM-20948)       | ICM-20948              | SPI           | Used for yaw/heading                   |
| Battery Sense     | Voltage divider      | -                      | Analog        | For battery monitoring                 |
| LoRa Radio        | LoRa transceiver     | LLCC68                 | SPI           | Telemetry, RadioLib                    |
| SD Card           | SD Card Module       | -                      | SPI           | Logging                                |
| Pyro Channels     | N-FETs + e-match     | IRLZ44N or similar     | Digital Out   | Drogue/Main deployment                 |
| Pyro Continuity   | Analog divider       | -                      | Analog        | E-match continuity check               |
| LEDs/Buzzer       | Status indicators    | -                      | Digital Out   | (Optional)                             |

## Key Pin Assignments (see core/config.h)
- IMU_CS: GPIO5
- LORA: NSS=10, DIO1=1, NRST=6, BUSY=4
- I2C (BARO/RTC/LIGHT): SDA=21, SCL=22
- GPS: TX=44, RX=43, PPS=14
- Vibration: DO=32, AO=34
- Thermistor: 36
- Pyro: 12
- SD Card: SS=13
- Battery ADC: 1

## Notes
- All sensors are checked for health at startup.
- IMU, Baro, GPS, Light, Vibration, Thermistor, RTC, Magnetometer are all used in fusion/logic.
- LoRa radio is used for telemetry, SD for logging.
- Pyro channels are for recovery deployment.
- Pin numbers are from config.h and may be changed for your hardware.
