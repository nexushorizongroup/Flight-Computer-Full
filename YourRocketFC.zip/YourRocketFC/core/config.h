#pragma once
#include <Arduino.h>

// -------------------------------
// Pin Assignments
// -------------------------------
#define PIN_IMU_CS       5 // IMU chip select (keep as 5 if not used by LoRa)
#define PIN_IMU_INT      27

#define PIN_VIBRATION_DO 32
#define PIN_VIBRATION_AO 34

#define PIN_LIGHT_SDA    21
#define PIN_LIGHT_SCL    22

#define PIN_BARO_SDA     21
#define PIN_BARO_SCL     22

#define PIN_RTC_SDA      21
#define PIN_RTC_SCL      22

#define PIN_GPS_TX       44
#define PIN_GPS_RX       43
#define PIN_GPS_PPS      14

#define PIN_THERMISTOR   36

#define PIN_PYRO         12

// --- LORA Hardware Pins (ESP32-S3 + LLCC68) ---
#define PIN_SD_SS 13 // SD card chip select (define as 13, adjust as needed)
#define NSS_PIN  10
#define DIO1_PIN 1
#define NRST_PIN 6 // LoRa RESET (changed from 5 to 6 to avoid IMU CS overlap)
#define BUSY_PIN 4 // LoRa BUSY

// -------------------------------
// Drogue Logic
// -------------------------------
#define USE_DROGUE false

// -------------------------------
// FreeRTOS Task Rates
// -------------------------------
#define RATE_IMU_HZ      800
#define RATE_FUSION_HZ   200
#define RATE_IO_HZ       25

// -------------------------------
// Barometer
// -------------------------------
#define SEALEVEL_HPA     1013.25

// -------------------------------
// Apogee Logic
// -------------------------------
#define MAIN_DEPLOY_ALT  120.0f
#define APOGEE_LOW_ALT   150.0f

// -------------------------------
// Logging
// -------------------------------
#define LOG_RATE_HZ      50

// -------------------------------
// RTC
// -------------------------------
#define RTC_SYNC_INTERVAL_MS 1000
