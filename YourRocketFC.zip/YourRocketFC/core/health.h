#pragma once
#include <Arduino.h>
#include "globals.h"

// Initialize health system
void initHealth();

// Update health flags (called in fusion task)
void updateHealth();
