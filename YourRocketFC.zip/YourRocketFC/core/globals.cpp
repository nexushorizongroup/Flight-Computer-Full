#include "globals.h"

volatile uint64_t pps_last_us = 0;
volatile bool pps_flag = false;

uint64_t launchTimeUs = 0;