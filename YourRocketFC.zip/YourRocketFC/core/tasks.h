#pragma once
#include <Arduino.h>

// FreeRTOS task handles
extern TaskHandle_t taskIMU;
extern TaskHandle_t taskFusion;
extern TaskHandle_t taskIO;
extern TaskHandle_t loraTaskHandle;

// Task initialization
void initTasks();

// Individual task functions
void imuTask(void *param);
void fusionTask(void *param);
void ioTask(void *param);
void loraTask(void *pvParameters);