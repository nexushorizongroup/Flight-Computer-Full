include "watchdog.h"
include "globals.h"
include "../flight/recovery.h"
include "../sensors/imu.h"
include "../logging/sdlog.h"
include <esptaskwdt.h>
include <esp_system.h>

bool watchdog_tripped = false;
bool imustalldetected = false;
bool sdstalldetected = false;

// IMU stall detection
static uint64_t lastIMUUpdate = 0;
static const uint32t IMUSTALLTIMEOUTUS = 50000; // 50 ms

// SD stall detection
static uint64_t lastSDWrite = 0;
static const uint32t SDSTALLTIMEOUTUS = 200000; // 200 ms

void initWatchdogs() {
    // Enable system watchdog (5 seconds)
    esptaskwdt_init(5, true);

    // Add current task (main loop)
    esptaskwdt_add(NULL);

    lastIMUUpdate = globalTimeUs;
    lastSDWrite = globalTimeUs;
}

void feedTaskWatchdog() {
    esptaskwdt_reset();
}

void feedSystemWatchdog() {
    // System WDT is fed automatically by task WDT
}

void updateIMUStallWatchdog() {
    if ((globalTimeUs - lastIMUUpdate) > IMUSTALLTIMEOUT_US) {
        imustalldetected = true;
        watchdog_tripped = true;
        recoveryMode = true;
    }
}

void updateSDStallWatchdog() {
    if ((globalTimeUs - lastSDWrite) > SDSTALLTIMEOUT_US) {
        sdstalldetected = true;
        watchdog_tripped = true;
        recoveryMode = true;
    }
}

// Called by IMU update function
void notifyIMUUpdated() {
    lastIMUUpdate = globalTimeUs;
}

// Called by SD logging function
void notifySDWrite() {
    lastSDWrite = globalTimeUs;
}
