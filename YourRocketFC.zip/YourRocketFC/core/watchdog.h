pragma once

include <Arduino.h>

void initWatchdogs();
void feedTaskWatchdog();
void feedSystemWatchdog();

extern bool watchdog_tripped;
extern bool imustalldetected;
extern bool sdstalldetected;
