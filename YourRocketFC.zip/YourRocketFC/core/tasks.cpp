#include "tasks.h"
#include "config.h"
#include "globals.h"

#include "../sensors/imu.h"
#include "../sensors/baro.h"
#include "../sensors/gps.h"
#include "../sensors/light.h"
#include "../sensors/vibration.h"
#include "../sensors/thermistor.h"
#include "../sensors/rtc.h"
#include "../sensors/lora.h"

#include "../fusion/ahrs.h"
#include "../fusion/kalman.h"
#include "../fusion/ekf_gating.h"
#include "../fusion/gps_lag.h"
#include "../fusion/ekf_bias.h"
#include "../fusion/ekf_conditioning.h"
#include "../fusion/sensor_opt.h"
#include "../fusion/time_fusion.h"

#include "../flight/state_machine.h"
#include "../flight/apogee.h"
#include "../flight/pyro.h"

#include "../logging/sdlog.h"
#include "../logging/ringbuffer.h"

TaskHandle_t taskIMU;
TaskHandle_t taskFusion;
TaskHandle_t taskIO;
TaskHandle_t loraTaskHandle;

void imuTask(void *param) {
    const TickType_t delay = pdMS_TO_TICKS(1000 / RATE_IMU_HZ);

    for (;;) {
        readIMU();
        updateAHRS();
        preintegrateIMU();
        xTaskNotifyGive(taskFusion); 
        feedTaskWatchdog();
        vTaskDelayUntil(&lastWake, delay);
    }
}

void fusionTask(void *param) {
    for (;;) {
        // Wait indefinitely for a notification from the IMU task
        // This blocks the task (0% CPU) until the IMU task "gives" the notification
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        updateBaro();
        updateGPS();
	updateGPSFusion();
        updateLightSensor();
        updateLightExt();
        updateVibrationSensor();
        updateThermistor();


        optimizeIMU(1.0f / RATE_FUSION_HZ);
        updateMag();
        updateMagYaw();
        detectMagDisturbance();
        optimizeBaro(1.0f / RATE_FUSION_HZ);
        optimizeGPS(1.0f / RATE_FUSION_HZ);
        ekfAdaptiveNoiseUpdate();
        ekfInnovationGating();
        applyGPSLagCompensation();
        ekfBiasPredict(1.0f / RATE_FUSION_HZ);
        updateEKF();
        ekfConditionCovariance();
        ekfConsistencyCheck();
        ekfStateReset();

        updateTimeFusion();

        updateStateMachine();
        checkApogeeVotes();
        feedTaskWatchdog();
    }
}

void ioTask(void *param) {
    const TickType_t delay = pdMS_TO_TICKS(1000 / RATE_IO_HZ);

    for (;;) {
        readGPS();
        syncRTCWithGPS();
        logData();
        updateBattery();
        updatePyroContinuity();
        feedTaskWatchdog();
        vTaskDelayUntil(&lastWake, delay);
    }
}

//Interrupt Service Routine - Keep it very short!
#if defined(ESP_PLATFORM)
void IRAM_ATTR setFlag(void) {
#else
void setFlag(void) {
#endif
  xSemaphoreGiveFromISR(loraSemaphore, NULL);
}

//The Dedicated LoRa Task
void loraTask(void *pvParameters) {
  TelemetryPacket packet;
  loraSemaphore = xSemaphoreCreateBinary();
  const TickType_t delay = pdMS_TO_TICKS(200 / RATE_IO_HZ);
  
  // Attach the interrupt to DIO1_PIN
  radio.setPacketSentAction(setFlag);

  for (;;) {
    // Wait for a packet to be pushed into the queue (blocking the task, not the CPU)
    if (xQueueReceive(telemetryQueue, &packet, portMAX_DELAY)) {
      
      // Start non-blocking transmission
      int state = radio.startTransmit((uint8_t*)&packet, sizeof(TelemetryPacket));
      
      if (state == RADIOLIB_ERR_NONE) {
        // Wait for the ISR to signal completion (with a 200ms safety timeout)
        if (xSemaphoreTake(loraSemaphore, delay)) {
            // Success! Packet is gone.
            radio.finishTransmit(); // Cleans up radio state
        }
      }
    }
    feedTaskWatchdog();  
  }
}

void initTasks() {
    xTaskCreatePinnedToCore(imuTask, "IMU", 12288, NULL, 4, &taskIMU, 0);
    xTaskCreatePinnedToCore(fusionTask, "Fusion", 8192, NULL, 3, &taskFusion, 0);
    xTaskCreatePinnedToCore(ioTask, "IO", 8192, NULL, 2, &taskIO, 1);

    telemetryQueue = xQueueCreate(3, sizeof(TelemetryPacket)); // Hold up to 3 packets
    // Pin task to Core 1 (leave Core 0 for EKF/Flight Logic)
    xTaskCreatePinnedToCore(loraTask, "LoRaTask", 8192, NULL, 1, &loraTaskHandle, 1);
}
