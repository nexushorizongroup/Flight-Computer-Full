#include "health.h"
#include "globals.h"
#include "../fusion/gps_fusion.h"
#include "../sensors/imu.h"
#include "../sensors/baro.h"
#include "../sensors/gps.h"
#include "../sensors/light.h"
#include "../sensors/vibration.h"
#include "../sensors/thermistor.h"
#include "../sensors/rtc.h"


void initHealth() {
    health.imu_ok = false;
    health.baro_ok = false;
    health.gps_ok = false;
    health.rtc_ok = false;
    health.light_ok = false;
    health.vibration_ok = false;
    health.thermistor_ok = false;

    health.pyro_armed = false;
}

void updateHealth() {

    // -----------------------------
    // IMU Health
    // -----------------------------
    float accel_mag = sqrtf(imu_ax*imu_ax + imu_ay*imu_ay + imu_az*imu_az);
    bool accel_ok = (accel_mag > 5.0f && accel_mag < 20.0f); // 0.5g–2g at rest/flight
    bool gyro_ok = (fabs(imu_gx) < 50.0f && fabs(imu_gy) < 50.0f && fabs(imu_gz) < 50.0f);

    float mag_norm = sqrtf(mx*mx + my*my + mz*mz);
    bool mag_range_ok = (mag_norm > 20.0f && mag_norm < 70.0f);

    health.mag_ok = mag_range_ok;

    health.imu_ok = accel_ok && gyro_ok;

    // IMU temp sanity
    health.imu_ok &= (imu_temp > -40.0f && imu_temp < 85.0f);


    // -----------------------------
    // Barometer Health
    // -----------------------------
    bool baro_range_ok = (baro_alt > -200.0f && baro_alt < 50000.0f);
    bool baro_vel_ok = (fabs(baro_vel) < 500.0f);

    health.baro_ok = baro_range_ok && baro_vel_ok;
    // Baro temp sanity
    health.baro_ok &= (baro_temp > -40.0f && baro_temp < 85.0f);



    // -----------------------------
    // GPS Health
    // -----------------------------
    health.gps_ok = gps_fused_valid;
    health.gps_ok &= (gps_quality > 0.2f);


    // -----------------------------
    // RTC Health
    // -----------------------------
    static uint64_t lastRTC = 0;
    uint64_t nowRTC = getRTCTimeUs();

    bool rtc_ok = (nowRTC > lastRTC);
    lastRTC = nowRTC;

    health.rtc_ok = rtc_ok;


    // -----------------------------
    // Light Sensor Health
    // -----------------------------
    bool light_ok = (light_lux >= 0.0f && light_lux < 200000.0f);

    health.light_ok = light_ok;
    health.light_ok &= !lightanomaly;

    // -----------------------------
    // Vibration Sensor Health
    // -----------------------------
    bool vib_ok = (vibration_level >= 0.0f && vibration_level <= 1.0f);
    health.vibration_ok = vib_ok;


    // -----------------------------
    // Thermistor Health
    // -----------------------------
    bool temp_ok = (thermistor_temp > -40.0f && thermistor_temp < 125.0f);
    health.thermistor_ok = temp_ok;
}

