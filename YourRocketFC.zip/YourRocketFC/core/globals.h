#pragma once
#include <Arduino.h>

extern volatile uint64_t pps_last_us;
extern volatile bool pps_flag;

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"

// Globals for FreeRTOS
QueueHandle_t telemetryQueue;
SemaphoreHandle_t loraSemaphore;

// Global time (microseconds) from RTC + GPS fusion
extern uint64_t globalTimeUs;

// Launch time (microseconds)
extern uint64_t launchTimeUs;

// System health structure
struct SystemHealth {
    bool imu_ok;
    bool baro_ok;
    bool gps_ok;
    bool rtc_ok;
    bool light_ok;
    bool vibration_ok;
    bool thermistor_ok;

    bool pyro_armed;
};

extern SystemHealth health;

// Flight state
extern volatile int flightState;

// Shared sensor data
extern float imu_ax, imu_ay, imu_az;
extern float imu_gx, imu_gy, imu_gz;
extern float imu_pitch, imu_roll, imu_yaw;

extern float baro_alt;
extern float baro_vel;

extern float gps_alt;
extern bool gps_valid;
extern float gps_alt_fused;
extern float gps_vel_fused;
extern bool gps_fused_valid;

extern float light_lux;
extern float light_derivative;

extern float vibration_level;
extern bool vibration_event;

extern float thermistor_temp;

extern unsigned long last_tx_time;
extern uint16_t tx_interval;

extern float battery_voltage;
extern bool battery_low;
extern bool battery_critical;

extern bool watchdog_tripped;
extern bool imustalldetected;
extern bool sdstalldetected;
