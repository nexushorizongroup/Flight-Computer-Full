#include "pps.h"
#include "../core/globals.h"

void IRAM_ATTR ppsISR() {
    pps_last_us = micros();
    pps_flag = true;
}
