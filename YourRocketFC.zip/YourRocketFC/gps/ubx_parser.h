#pragma once
#include <Arduino.h>

void initUBXParser();
void ubxProcessByte(uint8_t b);

extern float ubx_lat;
extern float ubx_lon;
extern float ubx_alt;
extern float ubx_veld;
extern float ubx_hAcc;
extern float ubx_vAcc;
extern uint8_t ubx_fixType;
extern uint8_t ubx_sats;
extern bool ubx_valid;
extern uint32_t ubx_tow_ms;
extern bool ubx_pps_valid;
