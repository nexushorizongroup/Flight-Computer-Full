#pragma once
#include <Arduino.h>
void sendUBXConfig(Stream& gps);
void configureGPS(Stream& gps);
