#include "ubx_parser.h"

static const uint8_t UBX_SYNC1 = 0xB5;
static const uint8_t UBX_SYNC2 = 0x62;

enum UBXState {
    WAIT_SYNC1,
    WAIT_SYNC2,
    READ_CLASS,
    READ_ID,
    READ_LEN1,
    READ_LEN2,
    READ_PAYLOAD,
    READ_CKA,
    READ_CKB
};

static UBXState state = WAIT_SYNC1;
static uint8_t msgClass, msgId;
static uint16_t payloadLen;
static uint16_t payloadIdx;
static uint8_t ckA, ckB;
static uint8_t payload[128];

float ubx_lat = 0;
float ubx_lon = 0;
float ubx_alt = 0;
float ubx_veld = 0;
float ubx_hAcc = 0;
float ubx_vAcc = 0;
uint8_t ubx_fixType = 0;
uint8_t ubx_sats = 0;
bool ubx_valid = false;
uint32_t ubx_tow_ms = 0;
bool ubx_pps_valid = false;

void initUBXParser() {
    state = WAIT_SYNC1;
}

static void ubxChecksum(uint8_t b) {
    ckA += b;
    ckB += ckA;
}

static void parseNAV_PVT() {
    ubx_tow_ms = *(uint32_t*)&payload[0];
    int32_t lat = *(int32_t*)&payload[28];
    int32_t lon = *(int32_t*)&payload[24];
    int32_t height = *(int32_t*)&payload[32];
    int32_t velD = *(int32_t*)&payload[60];
    ubx_fixType = payload[20];
    ubx_sats = payload[23];
    ubx_hAcc = *(uint32_t*)&payload[40] * 0.001f;
    ubx_vAcc = *(uint32_t*)&payload[44] * 0.001f;
    ubx_lat = lat * 1e-7f;
    ubx_lon = lon * 1e-7f;
    ubx_alt = height * 0.001f;
    ubx_veld = velD * 0.001f;
    ubx_valid = (ubx_fixType >= 3);
}

static void parseTIM_TP() {
    ubx_pps_valid = true;
    // PPS time-of-week is at payload[4]
    ubx_tow_ms = *(uint32_t*)&payload[4];
}

void ubxProcessByte(uint8_t b) {
    switch (state) {
    case WAIT_SYNC1:
        if (b == UBX_SYNC1) state = WAIT_SYNC2;
        break;
    case WAIT_SYNC2:
        if (b == UBX_SYNC2) state = READ_CLASS;
        else state = WAIT_SYNC1;
        break;
    case READ_CLASS:
        msgClass = b;
        ckA = ckB = 0;
        ubxChecksum(b);
        state = READ_ID;
        break;
    case READ_ID:
        msgId = b;
        ubxChecksum(b);
        state = READ_LEN1;
        break;
    case READ_LEN1:
        payloadLen = b;
        ubxChecksum(b);
        state = READ_LEN2;
        break;
    case READ_LEN2:
        payloadLen |= (b << 8);
        ubxChecksum(b);
        payloadIdx = 0;
        if (payloadLen > sizeof(payload)) {
            state = WAIT_SYNC1;
        } else {
            state = READ_PAYLOAD;
        }
        break;
    case READ_PAYLOAD:
        payload[payloadIdx++] = b;
        ubxChecksum(b);
        if (payloadIdx >= payloadLen) state = READ_CKA;
        break;
    case READ_CKA:
        if (b == ckA) state = READ_CKB;
        else state = WAIT_SYNC1;
        break;
    case READ_CKB:
        if (b == ckB) {
            if (msgClass == 0x01 && msgId == 0x07) parseNAV_PVT();
            if (msgClass == 0x0D && msgId == 0x01) parseTIM_TP();
        }
        state = WAIT_SYNC1;
        break;
    }
}
