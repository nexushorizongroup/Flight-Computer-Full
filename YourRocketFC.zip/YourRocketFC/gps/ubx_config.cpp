#include "ubx_config.h"

static void sendUBX(Stream& gps, const uint8_t* data, uint16_t len) {
    gps.write(data, len);
    gps.flush();
    delay(10);
}

// Example UBX config packets (NAV-PVT, 10 Hz, airborne <4g)
static const uint8_t CFG_RATE_10HZ[] = {0xB5,0x62,0x06,0x08,6,0,0x64,0x00,0x01,0x00,0x01,0x00};
static const uint8_t CFG_NAV5_AIRBORNE[] = {0xB5,0x62,0x06,0x24,36,0,0xFF,0xFF,0x06,0x03,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const uint8_t CFG_MSG_NAVPVT[] = {0xB5,0x62,0x06,0x01,3,0,0x01,0x07,0x01};
static const uint8_t CFG_MSG_TIMTP[] = {0xB5,0x62,0x06,0x01,3,0,0x0D,0x01,0x01};

void sendUBXConfig(Stream& gps) {
    sendUBX(gps, CFG_RATE_10HZ, sizeof(CFG_RATE_10HZ));
    sendUBX(gps, CFG_NAV5_AIRBORNE, sizeof(CFG_NAV5_AIRBORNE));
    sendUBX(gps, CFG_MSG_NAVPVT, sizeof(CFG_MSG_NAVPVT));
    sendUBX(gps, CFG_MSG_TIMTP, sizeof(CFG_MSG_TIMTP));
}

void configureGPS(Stream& gps) {
    sendUBXConfig(gps);
}
