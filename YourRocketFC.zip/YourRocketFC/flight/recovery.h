#pragma once
#include <Arduino.h>

void initRecoverySystem();
void updateRecoverySystem();

// Recovery flags
extern bool recoveryMode;
extern bool sensorFault;
extern bool ekfFault;
extern bool gpsFault;
extern bool baroFault;
extern bool imuFault;

// Safe descent trigger
extern bool forceMainDeploy;
