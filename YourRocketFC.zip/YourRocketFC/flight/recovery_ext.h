#pragma once
#include <Arduino.h>

void updateRecoverySystem();

extern bool recoveryMode;
extern bool ekfFault;
extern bool sensorFault;
extern bool forceDrogueDeploy;
extern bool forceMainDeploy;
