#pragma once
#include <Arduino.h>

void initPyroSystem();
void fireDrogue();
void fireMain();

