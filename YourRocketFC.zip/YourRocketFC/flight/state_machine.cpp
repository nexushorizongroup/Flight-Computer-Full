#include "state_machine.h"
#include "../core/globals.h"
#include "../core/config.h"

#include "../fusion/kalman.h"
#include "../fusion/ahrs.h"
#include "../fusion/time_fusion.h"

#include "recovery.h"
#include "recovery_ext.h"
#include "apogee.h"
#include "pyro.h"
#include "lora.h"

volatile int flightState = PAD;

static uint64_t tFlight = 0;

TelemetryPacket packet;

unsigned long last_tx_time = 0;
uint16_t tx_interval = 1000; // Default: 1 second (Ground/Pad mode)

static inline uint64_t tFlightUs() {
    return (launchTimeUs == 0) ? 0 : (globalTimeUs - launchTimeUs);
}

static bool timeInStateMs(uint32_t ms) {
    return (globalTimeUs - tFlight) / 1000ULL >= ms;
}

static void enterState(FlightState s) {
    flightState = s;
    tFlight = launchTimeUs;
    Serial.print("STATE → ");
    Serial.println(s);
}

void updateStateMachine() {
    // Recovery logic update
    updateRecoverySystem();

    switch (flightState) {

    // ---------------------------------------------------------
    case PAD:
        tx_interval = 1000; // Slow updates on pad
        if (imu_ax > 3.0f && vibration_event) {
            enterState(LAUNCH_DETECT);
        }
        break;

    // ---------------------------------------------------------
    case LAUNCH_DETECT:
        if (timeInStateMs(50)) {
            launchTimeUs = globalTimeUs; // <-- T+0
            enterState(BOOST);
        }
        break;

    // ---------------------------------------------------------
    case BOOST:
        tx_interval = 50;  // 20Hz - Maximum speed during boost
        if (imu_ax < 0.5f && !vibration_event) {
            enterState(MACH_LOCK);
        }
        break;

    // ---------------------------------------------------------
    case MACH_LOCK:
        if (timeInStateMs(500) && fabs(imu_ax) < 0.3f) {
            enterState(COAST);
        }
        break;

    // ---------------------------------------------------------
    case COAST:
        tx_interval = 100; // 10Hz - High speed to catch Apogee
        // Mach lock for first 1.0 seconds after launch
        if (tFlightUs() < 1000000ULL) {
            machLock = true;
        } else {
            machLock = false;
        }

        // If light derivative is large negative → cloud → baro unreliable
        if (lightluxderiv < -5000.0f) {
            machLock = true; // extend Mach lock
        }

	if (forceMainDeploy) {
    	    enterState(MAIN_DEPLOY);
    	    return;
	}
        if (apogeeDetected()) {
            enterState(APOGEE_DETECT);
        }
        break;

    // ---------------------------------------------------------
    case APOGEE_DETECT:
	if (forceMainDeploy) {
    	    enterState(MAIN_DEPLOY);
    	    return;
	}
        if (USE_DROGUE) {
            enterState(DROGUE_DEPLOY);
        } else {
            // Smart logic (A3)
            if (ekf_alt < APOGEE_LOW_ALT) {
                enterState(MAIN_DEPLOY);
            } else {
                // Wait until main deploy altitude
                if (ekf_alt < MAIN_DEPLOY_ALT) {
                    enterState(MAIN_DEPLOY);
                }
            }
        }
        break;

    // ---------------------------------------------------------
    case DROGUE_DEPLOY:
        fireDrogue();
        firePyro1();
        tx_interval = 500; // 2Hz - Moderate speed for tracking
        if (ekf_alt < MAIN_DEPLOY_ALT) {
            enterState(MAIN_DEPLOY);
        }

        break;

    // ---------------------------------------------------------
    case MAIN_DEPLOY:
        fireMain();
        firePyro2();
        tx_interval = 500; // 2Hz - Moderate speed for tracking
	if (forceMainDeploy) fireMain();
        if (fabs(ekf_vel) < 0.5f && !vibration_event && tFlightUs() > 5000000ULL && fabs(gps_vel_fused) < 1.0f) {
            enterState(LANDED);
        }

        break;

    // ---------------------------------------------------------
    case LANDED:
        tx_interval = 3000; // 0.3Hz - Very slow "Beacon" for recovery
        // Do nothing — safe state
        break;
    }

    // TIMED TRANSMISSION
    if (globalTimeUs - last_tx_time >= tx_interval) { 
        // Pack data and Transmit (Non-blocking is better, but start with this)
        prepare_and_send();
        last_tx_time = globalTimeUs;
    }
}
