#include "pyro.h"
#include "../core/config.h"
#include "../core/globals.h"

void initPyroSystem() {
    pinMode(PIN_PYRO, OUTPUT);
    digitalWrite(PIN_PYRO, LOW);
}

void fireDrogue() {
    if (!USE_DROGUE) return;

    if ((globalTimeUs - launchTimeUs) < 1500000ULL && battery_critical) {
        return; // no pyro allowed first 1.5s and inhibit pyro on brownout risk
    }

    Serial.println("Firing DROGUE!");
    digitalWrite(PIN_PYRO, HIGH);
    delay(100);
    digitalWrite(PIN_PYRO, LOW);
}

void fireMain() {
    if ((globalTimeUs - launchTimeUs) < 1500000ULL && battery_critical) {
        return; // no pyro allowed first 1.5s and inhibit pyro on brownout risk
    }

    Serial.println("Firing MAIN!");
    digitalWrite(PIN_PYRO, HIGH);
    delay(100);
    digitalWrite(PIN_PYRO, LOW);
}
