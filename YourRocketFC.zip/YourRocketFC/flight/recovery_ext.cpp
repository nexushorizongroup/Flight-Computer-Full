#include "recovery_ext.h"
#include "../core/globals.h"
#include "../core/health.h"
#include "../fusion/kalman.h"
#include "../fusion/gps_fusion.h"
#include "../sensors/baro.h"
#include "../sensors/imu.h"
#include "../sensors/light_ext.h"
#include "../core/watchdog.h"
#include "pyro.h"
#include "state_machine.h"

bool recoveryMode = false;
bool ekfFault = false;
bool sensorFault = false;
bool forceDrogueDeploy = false;
bool forceMainDeploy = false;

static const float MAX_REASONABLE_ALT = 50000.0f;
static const float MAX_REASONABLE_VEL = 800.0f;

void updateRecoverySystem() {
    // 1. EKF Fault Detection
    if (fabs(ekf_alt) > MAX_REASONABLE_ALT || fabs(ekf_vel) > MAX_REASONABLE_VEL || isnan(ekf_alt) || isnan(ekf_vel)) {
        ekfFault = true;
        recoveryMode = true;
    }
    if (gps_fused_valid && fabs(ekf_vel - gps_vel_fused) > 50.0f) {
        ekfFault = true;
        recoveryMode = true;
    }
    // 2. Sensor Fault Voting
    int bad = 0;
    if (!health.imu_ok) bad++;
    if (!health.baro_ok) bad++;
    if (!health.gps_ok) bad++;
    if (!health.light_ok) bad++;
    sensorFault = (bad >= 2);
    if (sensorFault) recoveryMode = true;
    // 3. Watchdog Integration
    if (watchdog_tripped) {
        recoveryMode = true;
        forceMainDeploy = true;
    }
    // 4. Battery Integration
    if (battery_critical) {
        recoveryMode = true;
        forceMainDeploy = true;
    }
    // 5. Cloud Detection → Baro Fallback
    if (cloud_detected && tFlightUs() > 2000000ULL) {
        baro_valid = false;
    }
    // 6. Fallback Modes
    if (ekfFault) {
        ekf_alt = baro_alt;
        ekf_vel = baro_vel;
    }
    if (!health.baro_ok && gps_fused_valid) {
        ekf_alt = gps_alt_fused;
        ekf_vel = gps_vel_fused;
    }
    if (!gps_fused_valid && health.baro_ok) {
        // Baro-only fallback: Already handled by EKF
    }
    // 7. Safe Descent Logic
    if (tFlightUs() > 5000000ULL && ekf_alt < 250.0f) {
        forceMainDeploy = true;
    }
    if (ekf_vel < -40.0f && flightState < DROGUE_DEPLOY) {
        forceDrogueDeploy = true;
    }
    // 8. Pyro Fallback Logic
    if (forceDrogueDeploy && pyro1_cont) {
        firePyro1();
    }
    if (forceMainDeploy && pyro2_cont) {
        firePyro2();
    }
}
