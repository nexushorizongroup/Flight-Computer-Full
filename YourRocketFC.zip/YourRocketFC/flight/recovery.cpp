#include "recovery.h"
#include "../core/globals.h"
#include "../core/config.h"

#include "../fusion/kalman.h"
#include "../fusion/gps_fusion.h"
#include "../sensors/baro.h"
#include "../sensors/imu.h"
#include "../sensors/gps.h"

#include "pyro.h"

bool recoveryMode = false;
bool sensorFault = false;
bool ekfFault = false;
bool gpsFault = false;
bool baroFault = false;
bool imuFault = false;

bool forceMainDeploy = false;

static uint64_t lastGoodGPS = 0;
static uint64_t lastGoodBaro = 0;
static uint64_t lastGoodIMU = 0;

static const uint32_t SENSOR_TIMEOUT_MS = 500;
static const float EKF_DIVERGENCE_THRESH = 50.0f;

void initRecoverySystem() {
    recoveryMode = false;
    sensorFault = false;
    ekfFault = false;
    gpsFault = false;
    baroFault = false;
    imuFault = false;
    forceMainDeploy = false;


    lastGoodGPS = globalTimeUs;
    lastGoodBaro = globalTimeUs;
    lastGoodIMU = globalTimeUs;
}

static void checkSensorHealth() {
    uint64_t now = globalTimeUs;

    // GPS
    if (gps_fused_valid) lastGoodGPS = now;
    gpsFault = ((now - lastGoodGPS) / 1000ULL) > SENSOR_TIMEOUT_MS;

    if (gps_quality < 0.1f && tFlightUs() > 2000000ULL) {
        // GPS unreliable → rely more on baro
        gps_fused_valid = false;
    }

    if (cloud_detected && tFlightUs() > 2000000ULL) {
        // Baro unreliable → rely more on IMU/GPS
        baro_valid = false;
    }



    // Baro
    if (fabs(baro_vel) < 200.0f) lastGoodBaro = now;
    baroFault = ((now - lastGoodBaro) / 1000ULL) > SENSOR_TIMEOUT_MS;

    // IMU
    if (fabs(imu_ax) < 50.0f && fabs(imu_gx) < 20.0f) lastGoodIMU = now;
    imuFault = ((now - lastGoodIMU) / 1000ULL) > SENSOR_TIMEOUT_MS;

    if (!mag_ok) {
        // Magnetometer failure → disable yaw correction
        // but do not force main deploy
    }


    sensorFault = gpsFault || baroFault || imuFault;
}

static void checkEKFFault() {
    // EKF divergence detection
    float innovation = fabs(ekf_alt - baro_alt);
    if (innovation > EKF_DIVERGENCE_THRESH) {
        ekfFault = true;
    }

    if (fabs(ekf_vel - gps_vel_fused) > EKF_DIVERGENCE_THRESH) {
        ekfFault = true;
    }

}

static void resetEKF() {
    ekf_alt = baro_alt;
    ekf_vel = baro_vel;
    ekf_bias = 0;

    P[0][0] = 10;
    P[1][1] = 10;
    P[2][2] = 1;

    ekfFault = false;
}

static void checkSafeDescentFallback() {
    // If everything fails, deploy main at safe altitude
    if (ekf_alt < 250.0f && sensorFault && tFlightUs() > 5000000ULL && !(tFlightUs() < 1500000ULL)) {
        forceMainDeploy = true;
    }
}

static void pyroRetryLogic() {
    // If drogue failed, retry once
    if (flightState == DROGUE_DEPLOY && sensorFault) {
        fireDrogue();
    }

    // If main failed, retry once
    if (flightState == MAIN_DEPLOY && sensorFault) {
        fireMain();
    }

    if (flightState == DROGUEDEPLOY && pyro1_cont) {
        firePyro1();
    }

    if (flightState == MAINDEPLOY && pyro2_cont) {
        firePyro2();
    }

    if (tFlightUs() > 2000000ULL && flightState == DROGUEDEPLOY && pyro1_cont) {
        firePyro1();
    }

    // If sensors overheat, force main deploy
    if (imu_temp > 80.0f || baro_temp > 80.0f) {
        forceMainDeploy = true;
    }


}

void updateRecoverySystem() {
    checkSensorHealth();
    checkEKFFault();

    if (ekfFault) {
        resetEKF();
    }

    if (watchdog_tripped) {
        forceMainDeploy = true;
    }

    if (battery_critical) {
        forceMainDeploy = true;
    }

    checkSafeDescentFallback();
    pyroRetryLogic();

    recoveryMode = sensorFault || ekfFault || forceMainDeploy;
}

