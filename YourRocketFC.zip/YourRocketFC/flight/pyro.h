pragma once

include <Arduino.h>

void initPyro();
void updatePyroContinuity();


void firePyro1();
void firePyro2();

// Safety flags
extern bool pyro1_cont;
extern bool pyro2_cont;
extern bool pyro_inhibit;
