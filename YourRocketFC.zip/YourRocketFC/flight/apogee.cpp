#include "apogee.h"
#include "../core/globals.h"
#include "../core/config.h"

#include "../fusion/kalman.h"
#include "../fusion/ahrs.h"

bool apogeeVotes[9] = {false};
int apogeeVoteCount = 0;

void checkApogeeVotes() {
    apogeeVoteCount = 0;

    // 1. EKF vertical velocity falling
    apogeeVotes[0] = (ekf_vel < -1.0f);

    // 2. Baro derivative falling
    apogeeVotes[1] = (baro_vel < -0.5f);

    // 3. Altitude near max (simple heuristic)
    static float maxAlt = 0;
    if (ekf_alt > maxAlt) maxAlt = ekf_alt;
    apogeeVotes[2] = (ekf_alt < maxAlt - 1.0f);

    // 4. IMU vertical accel negative
    apogeeVotes[3] = (imu_az < -0.2f);

    // 5. GPS altitude falling
    apogeeVotes[4] = (gps_fused_valid && gps_alt_fused < ekf_alt - 1.0f);

    // 6. AHRS pitch sanity check
    apogeeVotes[5] = (fabs(imu_pitch) < 70.0f);

    // 7. Vibration low
    apogeeVotes[6] = (!vibration_event);

    // 8. Light derivative stable
    apogeeVotes[7] = (lightlux_deriv > -100.0f);

    // 9. GPS speed check
    apogeeVotes[8] = (gps_vel_fused < -5.0f);

    // Count votes
    for (int i = 0; i < 9; i++) {
        if (apogeeVotes[i]) apogeeVoteCount++;
    }
}

bool apogeeDetected() {
    if (tFlightUs() < 1200000ULL) {
        return false; // no apogee allowed yet, inhibit apogee for first 1.2s
    }

    return apogeeVoteCount >= 4;
}