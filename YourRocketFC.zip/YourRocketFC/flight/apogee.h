#pragma once
#include <Arduino.h>

void checkApogeeVotes();
bool apogeeDetected();

extern bool apogeeVotes[9];
extern int apogeeVoteCount;
