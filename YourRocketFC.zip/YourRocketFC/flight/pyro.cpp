#include "pyro.h"

#include "../core/globals.h"

#include "../sensors/battery.h"

#include "../flight/recovery.h"

// Pin assignments
static const int PYRO1_PIN = 7;   // D0
static const int PYRO2_PIN = 8;   // D1
static const int CONTINUITY_PIN = 5; // A4 (GPIO5)

// Continuity thresholds (ADC)
static const int CONTGOODMIN = 200;   // ~0.2V
static const int CONTGOODMAX = 2000;  // ~2.0V

bool pyro1_cont = false;
bool pyro2_cont = false;
bool pyro_inhibit = false;

void initPyro() {
    pinMode(PYRO1_PIN, OUTPUT);
    pinMode(PYRO2_PIN, OUTPUT);

    digitalWrite(PYRO1_PIN, LOW);
    digitalWrite(PYRO2_PIN, LOW);

    pinMode(CONTINUITY_PIN, INPUT);
}

void updatePyroContinuity() {
    int raw = analogRead(CONTINUITY_PIN);

    // Shared sense line: continuity is detected by firing each FET slightly
    // without actually igniting the ematch (safe micro-pulse)
    // This is the same technique used in Raven4.

    // Check Pyro 1
    digitalWrite(PYRO1_PIN, HIGH);
    delayMicroseconds(200);
    int raw1 = analogRead(CONTINUITY_PIN);
    digitalWrite(PYRO1_PIN, LOW);

    // Check Pyro 2
    digitalWrite(PYRO2_PIN, HIGH);
    delayMicroseconds(200);
    int raw2 = analogRead(CONTINUITY_PIN);
    digitalWrite(PYRO2_PIN, LOW);

    pyro1_cont = (raw1 > CONTGOODMIN && raw1 < CONTGOOD_MAX);
    pyro2_cont = (raw2 > CONTGOODMIN && raw2 < CONTGOOD_MAX);

    // Safety inhibit logic
    pyro_inhibit = battery_critical || recoveryMode;
}

void firePyro1() {
    if (!pyro1_cont) return;
    if (pyro_inhibit) return;
    if (tFlightUs() < 1500000ULL) {
        return; // no pyro allowed first 1.5s
    }

    digitalWrite(PYRO1_PIN, HIGH);
    delay(100);
    digitalWrite(PYRO1_PIN, LOW);
}

void firePyro2() {
    if (!pyro2_cont) return;
    if (pyro_inhibit) return;
    if (tFlightUs() < 1500000ULL) {
        return; // no pyro allowed first 1.5s
    }
    digitalWrite(PYRO2_PIN, HIGH);
    delay(100);
    digitalWrite(PYRO2_PIN, LOW);
}
