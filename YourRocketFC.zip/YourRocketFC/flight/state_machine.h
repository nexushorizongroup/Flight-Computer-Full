#pragma once
#include <Arduino.h>

enum FlightState {
    PAD = 0,
    LAUNCH_DETECT,
    BOOST,
    MACH_LOCK,
    COAST,
    APOGEE_DETECT,
    DROGUE_DEPLOY,
    MAIN_DEPLOY,
    LANDED
};

void updateStateMachine();
extern volatile int flightState;
static inline uint64_t tFlightUs();