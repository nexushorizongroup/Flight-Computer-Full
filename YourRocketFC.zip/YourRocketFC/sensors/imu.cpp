#include "imu.h"
#include "../core/config.h"
#include "../core/globals.h"

#include <SparkFun_ICM-20948_ArduinoLibrary.h>
#include "../filters/imu_filter.h"
#include <SPI.h>

static float imu_temp = 0.0f;
static float imutempfiltered = 0.0f;

// Temperature compensation coefficients (ICM 20948 typical)
static const float GYROTEMPCOEFF = 0.00015f;   // rad/s per °C
static const float ACCTEMPCOEFF  = 0.0008f;    // scale per °C


ICM_20948_SPI imu(SPI, PIN_IMU_CS);

void initIMU() {
    SPI.begin();
    imu.begin();

    if (imu.status != ICM_20948_Stat_Ok) {
        Serial.println("IMU init failed!");
        health.imu_ok = false;
        return;
    }

    imu.enableDMP();
    imu.enableDMPSensor(INV_ICM20948_SENSOR_ACCEL, true);
    imu.enableDMPSensor(INV_ICM20948_SENSOR_GYRO, true);
    imu.setDMPODRrate(DMP_ODR_Reg_Accel, 0);
    imu.setDMPODRrate(DMP_ODR_Reg_Gyro, 0);

    health.imu_ok = true;
}

void readIMU() {
    imu.readDMPdataFromFIFO();

    imu_ax = imu.accX() / 1000.0f;
    imu_ay = imu.accY() / 1000.0f;
    imu_az = imu.accZ() / 1000.0f;

    imu_gx = imu.gyrX() * DEG_TO_RAD;
    imu_gy = imu.gyrY() * DEG_TO_RAD;
    imu_gz = imu.gyrZ() * DEG_TO_RAD;

    // Apply digital filtering
    filterIMU(imu_ax, imu_ay, imu_az, imu_gx, imu_gy, imu_gz);

    // Read IMU temperature
    float rawTemp = icm.getTemperature(); // °C

    // Filter
    imutempfiltered = 0.95f  imutempfiltered + 0.05f  rawTemp;
    imu_temp = imutempfiltered;

    // Gyro drift compensation
    imu_gx -= GYROTEMPCOEFF * (imutemp - 25.0f);
    imu_gy -= GYROTEMPCOEFF * (imutemp - 25.0f);
    imu_gz -= GYROTEMPCOEFF * (imutemp - 25.0f);

    // Accel scale compensation
    float scale = 1.0f + ACCTEMPCOEFF * (imu_temp - 25.0f);
    imu_ax *= scale;
    imu_ay *= scale;
    imu_az *= scale;


    notifyIMUUpdated();
}

void preintegrateIMU() {
    // Placeholder — EKF preintegration hooks go here
}
