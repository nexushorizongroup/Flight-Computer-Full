include "light_ext.h"

include "light.h"

include "../core/globals.h"

// Filtered lux
float lightluxfiltered = 0.0f;

// Derivative (lux/sec)
float lightluxderiv = 0.0f;

// Cloud detection
bool cloud_detected = false;

// Anomaly detection
bool light_anomaly = false;

static float last_lux = 0.0f;

void updateLightExt() {
    cloud_detected = false;
    light_anomaly = false;

    // Low-pass filter (alpha = 0.1)
    lightluxfiltered = 0.9f * lightluxfiltered + 0.1f * light_lux;

    // Derivative (lux/sec)
    float dlux = (lightluxfiltered - last_lux) / (FUSIONDT);
    last_lux = lightluxfiltered;

    lightluxderiv = dlux;

    // Cloud detection: sudden drop in light
    cloud_detected = (dlux < -5000.0f); // tuned experimentally

    // Light anomaly detection
    light_anomaly = (lightluxfiltered < 0.0f || lightluxfiltered > 200000.0f);

    // If sun is directly overhead → lux saturates → ignore derivative
    if (lightluxfiltered > 150000.0f) {
        lightluxderiv = 0.0f;
    }

}
