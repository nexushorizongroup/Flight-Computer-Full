pragma once

#include <Arduino.h>

void initMag();
void updateMag();

extern float mx, my, mz;
extern bool mag_ok;
