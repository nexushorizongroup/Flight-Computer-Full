#include "baro.h"
#include "../core/config.h"
#include "../core/globals.h"

#include <SparkFun_MS5611_Arduino_Library.h>

MS5611 baro;

static float baro_temp = 0.0f;     // °C
static float barotempfiltered = 0.0f;

static float lastAlt = 0;

void initBaro() {
    Wire.begin(PIN_BARO_SDA, PIN_BARO_SCL);

    if (!baro.begin()) {
        Serial.println("Barometer init failed!");
        health.baro_ok = false;
        return;
    }

    baro.setOversampling(OSR_4096);
    health.baro_ok = true;
}

//void updateBaro() {
//    baro.read();
 //   float pressure = baro.getPressure();
 //   float temp = baro.getTemperature();

//    baro_alt = baro.altitude(pressure, SEALEVEL_HPA);

 //   baro_vel = (baro_alt - lastAlt) * RATE_FUSION_HZ;
//    lastAlt = baro_alt;
//}


void updateBaro() {
    baro.read();  // raw pressure + raw temp

    float rawTemp = baro.getTemperature(); // °C
    float rawPress = baro.getPressure();   // Pa

    // Filter temperature (alpha = 0.05)
    barotempfiltered = 0.95f  barotempfiltered + 0.05f  rawTemp;
    baro_temp = barotempfiltered;

    // Temperature corrected pressure (datasheet)
    float T = rawTemp + baro.getTemperatureCompensation();
    float P = rawPress + baro.getPressureCompensation(T);

    // Convert to altitude
    baro_alt = 44330.0f * (1.0f - powf(P / 101325.0f, 0.1903f));

    // Derivative
    static float lastalt = baroalt;
    barovel = (baroalt - lastalt) / (BARODT);
    lastalt = baroalt;
}

