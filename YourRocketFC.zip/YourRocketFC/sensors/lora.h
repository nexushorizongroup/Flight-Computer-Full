#include <cstdint>

// Define the structure
// --- Telemetry Structure (Packed for NASA-style efficiency) ---
struct __attribute__((packed)) TelemetryPacket {
    uint32_t ms;      // 4 bytes: Timestamp (ms since boot)
    float alt;        // 4 bytes: Altitude (meters AGL)
    //int32_t lat;      // 4 bytes: Latitude * 10^7
    //int32_t lon;      // 4 bytes: Longitude * 10^7
    //float batt;       // 4 bytes: Voltage (V)
    uint8_t state;    // 1 byte:  Current FlightState (0=Boost, 1=Coast, etc.)
    uint16_t checksum; // checksum
};

extern unsigned long last_tx_time;
extern uint16_t tx_interval; // Default: 1 second (Ground/Pad mode)

void initLora();
uint16_t get_crc();
void prepare_and_send();