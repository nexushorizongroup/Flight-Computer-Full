include "mag.h"

include "imu.h"

include "../core/globals.h"

// Raw magnetometer values
float mx = 0;
float my = 0;
float mz = 0;

bool mag_ok = false;

// Hard-iron offsets (to be calibrated)
static float magoffsetx = 0.0f;
static float magoffsety = 0.0f;
static float magoffsetz = 0.0f;

// Soft-iron scale factors
static float magscalex = 1.0f;
static float magscaley = 1.0f;
static float magscalez = 1.0f;

// Low-pass filter
static float mxf = 0, myf = 0, mz_f = 0;

void initMag() {
    // ICM-20948 must already be initialized in imu.cpp
    // Enable magnetometer
    icm.enableMagnetometer();
}

void updateMag() {
    float mx, my, mz;

    if (!icm.magAvailable()) {
        mag_ok = false;
        return;
    }

    icm.readMag(mx, my, mz);

    // Hard-iron correction
    mx -= magoffsetx;
    my -= magoffsety;
    mz -= magoffsetz;

    // Soft-iron correction
    mx *= magscalex;
    my *= magscaley;
    mz *= magscalez;

    // Low-pass filter
    mxf = 0.9f  mxf + 0.1f  mx;
    myf = 0.9f  myf + 0.1f  my;
    mzf = 0.9f  mzf + 0.1f  mz;

    magx = mxf;
    magy = myf;
    magz = mzf;

    // Sanity check
    float mag_norm = sqrtf(mxfmxf + myfmyf + mzf*mz_f);
    mag_ok = (mag_norm > 20.0f && mag_norm < 70.0f); // typical Earth field
}
