#pragma once
#include <Arduino.h>

void initRTC();
void syncRTCWithGPS();
uint64_t getRTCTimeUs();

extern bool rtc_synced;
