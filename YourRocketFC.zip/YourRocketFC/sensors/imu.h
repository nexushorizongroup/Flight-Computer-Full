#pragma once
#include <Arduino.h>

void initIMU();
void readIMU();
void preintegrateIMU();

// Shared IMU data
extern float imu_ax, imu_ay, imu_az;
extern float imu_gx, imu_gy, imu_gz;
extern float imu_pitch, imu_roll, imu_yaw;
