#pragma once
#include <Arduino.h>

void initThermistor();
void updateThermistor();

extern float thermistor_temp;
