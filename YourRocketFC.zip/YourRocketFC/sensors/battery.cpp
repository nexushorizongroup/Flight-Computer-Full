include "battery.h"

include "../core/config.h"

include "../core/globals.h"

// ADC pin for battery sense
static const int BATTERYADCPIN = 1;   // A0 (GPIO1)

// Voltage divider values
static const float R1 = 100000.0f;  // top resistor
static const float R2 = 33000.0f;   // bottom resistor

// ADC characteristics
static const float ADC_MAX = 4095.0f;
static const float ADC_REF = 3.30f;

// Filter
static float v_filtered = 0;

float battery_voltage = 0;
bool battery_low = false;
bool battery_critical = false;

void initBattery() {
    analogReadResolution(12);
    pinMode(BATTERYADCPIN, INPUT);
}

void updateBattery() {
    int raw = analogRead(BATTERYADCPIN);

    float vadc = (raw / ADCMAX) * ADC_REF;

    // Reverse voltage divider
    float vbatt = vadc * ((R1 + R2) / R2);

    // Low pass filter (alpha = 0.1)
    vfiltered = 0.9f  vfiltered + 0.1f  v_batt;

    battery_voltage = vfiltered;

    // Thresholds for 2S LiPo
    battery_low = (battery_voltage < 6.8f);
    battery_critical = (battery_voltage < 6.4f);
}
