#include "vibration.h"
#include "../core/config.h"
#include "../core/globals.h"

float vibration_level = 0;
bool vibration_event = false;

void initVibrationSensor() {
    pinMode(PIN_VIBRATION_DO, INPUT);
}

void updateVibrationSensor() {
    vibration_event = digitalRead(PIN_VIBRATION_DO);
    vibration_level = analogRead(PIN_VIBRATION_AO) / 4095.0f;
}
