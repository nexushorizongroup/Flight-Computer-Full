#include "gps.h"
#include "../core/config.h"
#include "../core/globals.h"

#include "../gps/ubx_parser.h"

HardwareSerial GPSSerial(1);

float gps_alt = 0;
bool gps_valid = false;

void initGPS() {
    GPSSerial.begin(115200, SERIAL_8N1, PIN_GPS_RX, PIN_GPS_TX);
    configureGPS(GPSSerial);
    pinMode(PIN_GPS_PPS, INPUT);
}

void readGPS() {
    while (GPSSerial.available()) {
        ubxProcessByte(GPSSerial.read());
    }
}

void updateGPS() {
    if (ubx_valid) {
        gps_alt = ubx_alt;
        gps_valid = true;
    } else {
        gps_valid = false;
    }
}
