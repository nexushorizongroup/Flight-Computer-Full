pragma once

#include <Arduino.h>

void updateLightExt();

extern float lightluxfiltered;
extern float lightluxderiv;
extern bool cloud_detected;
extern bool light_anomaly;
