#include "thermistor.h"
#include "../core/config.h"
#include "../core/globals.h"

float thermistor_temp = 0;

void initThermistor() {
    pinMode(PIN_THERMISTOR, INPUT);
}

void updateThermistor() {
    int raw = analogRead(PIN_THERMISTOR);
    float v = raw / 4095.0f * 3.3f;

    // Simple linear approximation — replace with Steinhart-Hart if needed
    thermistor_temp = (v - 0.5f) * 100.0f;
}
