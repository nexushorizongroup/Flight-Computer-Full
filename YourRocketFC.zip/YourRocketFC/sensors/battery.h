pragma once

include <Arduino.h>

void initBattery();
void updateBattery();

extern float battery_voltage;       // volts
extern bool battery_low;            // < 6.8V (2S LiPo)
extern bool battery_critical;       // < 6.4V (brownout risk)
