#pragma once
#include <Arduino.h>

void initVibrationSensor();
void updateVibrationSensor();

extern float vibration_level;
extern bool vibration_event;
