#include "rtc.h"
#include "../core/config.h"
#include "../core/globals.h"

#include <Wire.h>
#include <DS3231M.h>

DS3231M_Class rtc;

bool rtc_synced = false;

void initRTC() {
    Wire.begin(PIN_RTC_SDA, PIN_RTC_SCL);

    if (!rtc.begin()) {
        Serial.println("RTC init failed!");
        health.rtc_ok = false;
        return;
    }

    health.rtc_ok = true;
}

void syncRTCWithGPS() {
    if (!gps_valid) return;

    rtc.setEpoch(gps.time.value());
    rtc_synced = true;
}

uint64_t getRTCTimeUs() {
    return (uint64_t)rtc.getEpoch() * 1000000ULL;
}
