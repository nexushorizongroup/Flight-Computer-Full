#pragma once
#include <Arduino.h>

void initLightSensor();
void updateLightSensor();

extern float light_lux;
extern float light_derivative;
