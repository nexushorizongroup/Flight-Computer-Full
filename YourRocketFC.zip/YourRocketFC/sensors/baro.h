#pragma once
#include <Arduino.h>

void initBaro();
void updateBaro();

extern float baro_alt;
extern float baro_vel;
