#include "light.h"
#include "../core/config.h"
#include "../core/globals.h"

#include <Adafruit_Sensor.h>
#include <Adafruit_TSL2561_U.h>

Adafruit_TSL2561_Unified tsl = Adafruit_TSL2561_Unified(TSL2561_ADDR_FLOAT, 12345);

float light_lux = 0;
float light_derivative = 0;

static float lastLux = 0;

void initLightSensor() {
    if (!tsl.begin()) {
        Serial.println("TSL2561 init failed!");
        health.light_ok = false;
        return;
    }

    tsl.enableAutoRange(true);
    tsl.setIntegrationTime(TSL2561_INTEGRATIONTIME_13MS);

    health.light_ok = true;
}

void updateLightSensor() {
    sensors_event_t event;
    tsl.getEvent(&event);

    light_lux = event.light;
    light_derivative = (light_lux - lastLux) * RATE_FUSION_HZ;
    lastLux = light_lux;
}
