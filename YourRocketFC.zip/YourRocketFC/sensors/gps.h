#pragma once
#include <Arduino.h>

void initGPS();
void readGPS();
void updateGPS();

extern float gps_alt;
extern bool gps_valid;
