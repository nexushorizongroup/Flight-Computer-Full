#include "lora.h"
#include "../core/config.h"
#include "../core/globals.h"
#include "rom/crc.h" // Built into the ESP32 framework
#include <RadioLib.h>

// Create the module instance
// LLCC68(Module* mod);
SPIClass& spi = SPI; // Or your custom SPI
Module* mod = new Module(NSS_PIN, DIO1_PIN, NRST_PIN, BUSY_PIN); // CS, DIO1, RESET, BUSY
LLCC68 radio = LLCC68(mod);

void initLora() {
  // Initialize LoRa
  int state = radio.begin(); // Default: 434.0 MHz, 125 kHz BW
  if (state == RADIOLIB_ERR_NONE) {
    // Set for 915MHz if you are in the US
    radio.setFrequency(915.0); 
    // LIMITATION ALERT: LLCC68 only supports SF 5-9 at 125kHz BW. // SF10 is only supported at 250kHz, and SF11 at 500kHz. 
    radio.setSpreadingFactor(9); 
    // Max range for standard 125kHz BW 
    radio.setOutputPower(22); // Max power (22dBm)
  }
}

uint16_t get_crc(const uint8_t *data, size_t len) {
    // ESP32's rom_crc16_be uses the same 0x1021 polynomial
    // Note: The ROM function requires bitwise NOT (~) for start/end
    return ~crc16_be(~0xFFFF, data, len);
}

void prepare_and_send() {
    // Declare the instance
    TelemetryPacket data;
    data.ms = (uint32_t)((globalTimeUs - launchTimeUs) / 1000);
    data.alt = ekf_alt;
    // If lat/lon fields are present, fill from GPS
    // data.lat = (int32_t)(ubx_lat * 1e7);
    // data.lon = (int32_t)(ubx_lon * 1e7);
    // If batt field is present, fill from battery_voltage
    // data.batt = battery_voltage;
    data.state = (uint8_t)flightState;

    // Calculate CRC for all bytes EXCEPT the 2 bytes of the checksum field
    data.checksum = get_crc((uint8_t*)&data, sizeof(data) - sizeof(data.checksum));

    // Non-blocking: just drop it in the queue and return to flight logic
    // We use a 0 timeout so we don't wait if the queue is full (skipping is better than crashing)
    xQueueSend(telemetryQueue, &data, 0);
}