#include <Arduino.h>
#include "core/config.h"
#include "core/globals.h"
#include "core/tasks.h"
#include "core/health.h"

#include "sensors/imu.h"
#include "sensors/baro.h"
#include "sensors/gps.h"
#include "sensors/light.h"
#include "sensors/vibration.h"
#include "sensors/thermistor.h"
#include "sensors/rtc.h"
#include "sensors/lora.h"

#include "fusion/ahrs.h"
#include "fusion/kalman.h"
#include "fusion/sensor_opt.h"
#include "fusion/time_fusion.h"

#include "flight/state_machine.h"
#include "flight/pyro.h"
#include "flight/apogee.h"

#include "logging/sdlog.h"
#include "logging/ringbuffer.h"

void setup() {
    Serial.begin(115200);
    delay(200);

    Serial.println("=== YourRocketFC Boot ===");

    initConfig();
    initGlobals();
    initHealth();

    initRTC();
    initGPS();
    initIMU();
    initBaro();
    initLightSensor();
    initVibrationSensor();
    initThermistor();
    initLora();

    initAHRS();
    initEKF();
    initTimeFusion();

    initSD();
    initRingBuffer();

    initPyroSystem();

    initTasks();   // FreeRTOS task creation

    Serial.println("System initialized.");
}

void loop() {
    // Empty — FreeRTOS handles everything
}